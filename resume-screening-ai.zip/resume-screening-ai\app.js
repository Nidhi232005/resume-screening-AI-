// Aura AI - Resume Screening System Core Logic

// Set up pdf.js worker (loaded locally to bypass browser cross-origin Web Worker policies on file://)
pdfjsLib.GlobalWorkerOptions.workerSrc = './pdf.worker.min.js';

// Predefined JD templates
const jdTemplates = {
    'software-engineer': `Job Title: Senior Full-Stack Software Engineer
Department: Engineering
Location: Remote

Key Requirements & Responsibilities:
- 5+ years of experience building modern web applications using JavaScript and TypeScript.
- Strong proficiency with React.js, Next.js, and Node.js.
- Solid experience with databases like SQL (PostgreSQL) and NoSQL (MongoDB).
- Hand-on experience with cloud platforms (AWS, Docker, Kubernetes).
- Familiarity with Git, REST APIs, GraphQL, and CI/CD pipelines.
- Experience writing clean, maintainable code and unit tests.
- Collaborative mindset, working in agile sprints, strong communication skills.
- Bachelor's degree in Computer Science, Software Engineering or equivalent experience.`,

    'data-scientist': `Job Title: Data Scientist & AI Engineer
Department: Data Analytics
Location: Hybrid

Key Requirements & Responsibilities:
- 3+ years of experience in data science, predictive modeling, or machine learning roles.
- Expert programming skills in Python (highly preferred) or R.
- Deep knowledge of core libraries: Pandas, NumPy, Scikit-learn, TensorFlow, PyTorch.
- Experience with SQL and database querying for large datasets.
- Solid understanding of statistics, linear algebra, and data mining techniques.
- Experience deploying machine learning models to cloud services (GCP, AWS).
- Experience with NLP (Natural Language Processing) and LLMs is a big plus.
- Skill in data visualization tools like Tableau, PowerBI, or Matplotlib.
- Strong problem-solving skills and capability to explain complex analysis to stakeholders.`,

    'product-manager': `Job Title: Technical Product Manager
Department: Product Management
Location: New York, NY

Key Requirements & Responsibilities:
- 4+ years of experience as a Product Manager, Product Owner, or Technical Lead.
- Experience driving product roadmaps from concept to launch in an Agile / Scrum framework.
- Ability to write clear, actionable User Stories, Product Specification Docs (PRDs).
- Strong collaboration skills to manage stakeholders across Engineering, Design, and Marketing.
- Proficiency in analytics and data tools (SQL, Amplitude, Google Analytics, Excel).
- Experience running A/B testing, user research, and customer interviews.
- Familiarity with project tracking software like Jira and Confluence.
- Excellent written and verbal communication skills.
- Background in software engineering, technical design, or business analytics.`,

    'marketing-specialist': `Job Title: Growth Marketing Specialist
Department: Growth & Acquisition
Location: San Francisco, CA

Key Requirements & Responsibilities:
- 3+ years of growth marketing, digital acquisition, or product marketing experience.
- Deep expertise in SEO (Search Engine Optimization) and SEM/PPC advertising (Google Ads, Meta Ads).
- Proven track record tracking campaigns using Google Analytics, Google Tag Manager.
- High proficiency running email marketing campaigns and managing marketing CRM workflows (HubSpot, Salesforce).
- Strong analytical skills, managing A/B testing, conversion rate optimization (CRO).
- Excellent copywriting and content creation skills for ad copy, landing pages, and newsletters.
- Experience in growth hacking, viral mechanics, and referral programs.
- Comfortable working in fast-paced environments, with data-driven decision-making.`,

    'ui-ux-designer': `Job Title: Senior Product UI/UX Designer
Department: Product Design
Location: Remote

Key Requirements & Responsibilities:
- 4+ years of professional experience as a UI/UX Designer, Product Designer, or Interaction Designer.
- A strong portfolio demonstrating user research, wireframes, prototypes, and high-fidelity visuals.
- Mastery of Figma (highly preferred), Sketch, Adobe XD, and Creative Cloud tools.
- Experience conducting user research, usability testing, and developing user personas.
- In-depth understanding of information architecture, interaction models, and responsive design layouts.
- Ability to create and maintain design systems and component libraries.
- Basic understanding of frontend web development (HTML, CSS) to collaborate effectively with engineers.
- Strong presentation skills to articulate design decisions to stakeholders.`
};

// Skill Taxonomy Dictionary for Keyword Parsing
const skillTaxonomy = {
    'Technical': [
        'javascript', 'typescript', 'python', 'java', 'c++', 'c#', 'ruby', 'php', 'golang', 'rust', 
        'sql', 'mysql', 'postgresql', 'mongodb', 'redis', 'elasticsearch', 'sqlite', 'oracle',
        'react', 'angular', 'vue', 'next.js', 'node.js', 'django', 'flask', 'spring boot', 'laravel',
        'html', 'css', 'sass', 'tailwind', 'bootstrap', 'webpack', 'babel', 'vite',
        'aws', 'gcp', 'azure', 'docker', 'kubernetes', 'jenkins', 'git', 'github', 'gitlab', 'ci/cd',
        'graphql', 'rest api', 'microservices', 'serverless', 'firebase', 'supabase', 'prisma'
    ],
    'Data Science & AI': [
        'pandas', 'numpy', 'scikit-learn', 'tensorflow', 'pytorch', 'keras', 'machine learning', 
        'deep learning', 'nlp', 'natural language processing', 'computer vision', 'statistics', 
        'probability', 'r programming', 'spark', 'hadoop', 'tableau', 'powerbi', 'data visualization',
        'data mining', 'predictive modeling', 'data warehousing', 'llm', 'langchain', 'openai', 'huggingface'
    ],
    'Product & Management': [
        'agile', 'scrum', 'kanban', 'jira', 'confluence', 'product roadmap', 'prd', 'user stories',
        'wireframing', 'prototyping', 'product spec', 'amplitude', 'google analytics', 'sql', 'excel',
        'project management', 'stakeholder management', 'a/b testing', 'user research', 'customer interviews',
        'strategic planning', 'risk management', 'budgeting', 'sdlc', 'team leadership'
    ],
    'Marketing & Growth': [
        'seo', 'sem', 'ppc', 'google ads', 'meta ads', 'google analytics', 'hubspot', 'salesforce', 
        'crm', 'email marketing', 'copywriting', 'content marketing', 'growth hacking', 'cro',
        'conversion rate optimization', 'social media marketing', 'market research', 'competitive analysis',
        'brand strategy', 'public relations', 'lead generation', 'marketing automation'
    ],
    'UI/UX Design': [
        'figma', 'sketch', 'adobe xd', 'photoshop', 'illustrator', 'invision', 'wireframing', 
        'prototyping', 'user research', 'information architecture', 'interaction design', 'visual design', 
        'usability testing', 'design systems', 'storyboarding', 'user personas', 'ui design', 'ux design'
    ],
    'Soft Skills': [
        'leadership', 'communication', 'teamwork', 'collaboration', 'problem solving', 
        'critical thinking', 'time management', 'adaptability', 'conflict resolution', 'empathy', 
        'creativity', 'organization', 'negotiation', 'mentoring', 'active listening', 'presentation'
    ]
};

// Global App State
const state = {
    candidates: [],
    selectedCandidateId: null,
    currentJdText: '',
    filesPending: [],
    skillsChart: null
};

// Initialize Application UI
document.addEventListener('DOMContentLoaded', () => {
    initElements();
    setupEventListeners();
});

// Elements Store
let el = {};

function initElements() {
    el = {
        jdTemplateSelect: document.getElementById('jd-template-select'),
        jobDescriptionInput: document.getElementById('job-description-input'),
        
        dropZone: document.getElementById('drop-zone'),
        fileInput: document.getElementById('file-input'),
        fileListContainer: document.getElementById('file-list-container'),
        fileList: document.getElementById('file-list'),
        fileCount: document.getElementById('file-count'),
        
        btnRunAnalysis: document.getElementById('btn-run-analysis'),
        
        dashboardPlaceholder: document.getElementById('dashboard-placeholder'),
        dashboardResults: document.getElementById('dashboard-results'),
        
        candidateInitials: document.getElementById('candidate-initials'),
        candidateName: document.getElementById('candidate-name'),
        candidateFilename: document.getElementById('candidate-filename'),
        fitGradeBadge: document.getElementById('fit-grade-badge'),
        scoringMethod: document.getElementById('scoring-method'),
        
        scoreRadialFill: document.getElementById('score-radial-fill'),
        scorePercentage: document.getElementById('score-percentage'),
        
        metricSkillsVal: document.getElementById('metric-skills-val'),
        barSkillsMatch: document.getElementById('bar-skills-match'),
        metricProjectsVal: document.getElementById('metric-projects-val'),
        barProjectsMatch: document.getElementById('bar-projects-match'),
        metricEduVal: document.getElementById('metric-edu-val'),
        barEduMatch: document.getElementById('bar-edu-match'),
        metricQualityVal: document.getElementById('metric-quality-val'),
        barQualityMatch: document.getElementById('bar-quality-match'),
        
        countMatched: document.getElementById('count-matched'),
        countMissing: document.getElementById('count-missing'),
        matchedSkillsContainer: document.getElementById('matched-skills-container'),
        missingSkillsContainer: document.getElementById('missing-skills-container'),
        
        reportSummary: document.getElementById('report-summary'),
        reportStrengths: document.getElementById('report-strengths'),
        reportWeaknesses: document.getElementById('report-weaknesses'),
        reportQuestions: document.getElementById('report-questions'),
        
        leaderboardTbody: document.getElementById('leaderboard-tbody'),
        btnExportCsv: document.getElementById('btn-export-csv'),
        btnLoadDemo: document.getElementById('btn-load-demo'),
        
        spinnerModal: document.getElementById('spinner-modal'),
        spinnerTitle: document.getElementById('spinner-title'),
        spinnerSubtitle: document.getElementById('spinner-subtitle')
    };
}

// Event Binding
function setupEventListeners() {
    // Select JD Template
    el.jdTemplateSelect.addEventListener('change', (e) => {
        const key = e.target.value;
        if (key && jdTemplates[key]) {
            el.jobDescriptionInput.value = jdTemplates[key];
            state.currentJdText = jdTemplates[key];
        } else {
            el.jobDescriptionInput.value = '';
            state.currentJdText = '';
        }
        validateRunButton();
    });

    el.jobDescriptionInput.addEventListener('input', (e) => {
        state.currentJdText = e.target.value;
        validateRunButton();
    });

    // Drag and Drop files
    el.dropZone.addEventListener('click', () => el.fileInput.click());
    
    el.dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        el.dropZone.classList.add('dragover');
    });
    
    el.dropZone.addEventListener('dragleave', () => {
        el.dropZone.classList.remove('dragover');
    });
    
    el.dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        el.dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length > 0) {
            handleSelectedFiles(e.dataTransfer.files);
        }
    });

    el.fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleSelectedFiles(e.target.files);
        }
    });

    // Run Analysis
    el.btnRunAnalysis.addEventListener('click', () => runScreeningWorkflow());

    // Tabs navigation
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const tabId = e.target.getAttribute('data-tab');
            
            // Toggle active tabs buttons
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            
            // Toggle active panels
            document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
            
            // If radar tab selected, recalculate size/refresh
            if (tabId === 'tab-chart' && state.selectedCandidateId) {
                const cand = state.candidates.find(c => c.id === state.selectedCandidateId);
                if (cand) {
                    renderRadarChart(cand.skillsRadar);
                }
            }
        });
    });

    // Export CSV
    el.btnExportCsv.addEventListener('click', () => exportRankingsCsv());

    // Load Mock Data Profile
    el.btnLoadDemo.addEventListener('click', () => loadDemoProfile());
}

// Key check removed

// Check if Run Button should be active
function validateRunButton() {
    const hasJd = el.jobDescriptionInput.value.trim().length > 10;
    const hasFiles = state.filesPending.length > 0;
    el.btnRunAnalysis.disabled = !(hasJd && hasFiles);
}

// File processing setup
function handleSelectedFiles(fileList) {
    for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        if (file.type === 'application/pdf' || file.name.endsWith('.pdf') || file.type === 'text/plain' || file.name.endsWith('.txt')) {
            // Check for duplicates
            if (!state.filesPending.some(f => f.name === file.name && f.size === file.size)) {
                state.filesPending.push(file);
            }
        } else {
            showNotification(`Unsupported file type: ${file.name}. Only PDF and TXT are supported.`, 'warning');
        }
    }
    
    updatePendingFilesUI();
    validateRunButton();
}

function updatePendingFilesUI() {
    if (state.filesPending.length === 0) {
        el.fileListContainer.classList.add('hidden');
        return;
    }
    
    el.fileListContainer.classList.remove('hidden');
    el.fileCount.textContent = state.filesPending.length;
    el.fileList.innerHTML = '';
    
    state.filesPending.forEach((file, index) => {
        const item = document.createElement('div');
        item.className = 'file-item';
        
        const sizeKB = (file.size / 1024).toFixed(1);
        
        item.innerHTML = `
            <div class="file-info">
                <svg class="file-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
                <div class="file-meta">
                    <div class="file-name" title="${file.name}">${file.name}</div>
                    <div class="file-size">${sizeKB} KB</div>
                </div>
            </div>
            <button class="btn-icon delete-file-btn" data-index="${index}">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        `;
        
        el.fileList.appendChild(item);
    });
    
    // Bind remove button listeners
    document.querySelectorAll('.delete-file-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const btnEl = e.currentTarget;
            const index = parseInt(btnEl.getAttribute('data-index'));
            state.filesPending.splice(index, 1);
            updatePendingFilesUI();
            validateRunButton();
        });
    });
}

// Central Workflow Coordinator
async function runScreeningWorkflow() {
    showSpinner('Screening Resumes', 'Reading files and preparing text analysis engine...');
    
    const jdText = state.currentJdText;
    const candidatesProcessed = [];
    
    try {
        for (let i = 0; i < state.filesPending.length; i++) {
            const file = state.filesPending[i];
            updateSpinnerSub(`Reading file ${i+1}/${state.filesPending.length}: ${file.name}`);
            
            let text = '';
            if (file.name.endsWith('.pdf')) {
                text = await extractTextFromPdf(file);
            } else {
                text = await extractTextFromTxt(file);
            }
            
            updateSpinnerSub(`Analyzing resume match for ${file.name}...`);
            // Run High-Speed Local NLP Engine
            const evaluation = runLocalNLPScreener(text, jdText, file.name);
            evaluation.method = 'Local NLP Engine';
            
            candidatesProcessed.push(evaluation);
        }
        
        // Save processed candidates
        state.candidates = [...state.candidates, ...candidatesProcessed];
        state.filesPending = [];
        updatePendingFilesUI();
        validateRunButton();
        
        // Select the top-performing newly added candidate to display
        candidatesProcessed.sort((a, b) => b.score - a.score);
        if (candidatesProcessed.length > 0) {
            displayCandidateDetails(candidatesProcessed[0].id);
        }
        
        renderLeaderboard();
        showNotification(`Screened ${candidatesProcessed.length} candidates successfully!`);
    } catch (err) {
        console.error('Screening pipeline failed:', err);
        showNotification('Fatal error: ' + err.message, 'danger');
    } finally {
        hideSpinner();
    }
}

// PDF Text Extraction
function extractTextFromPdf(file) {
    return new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.onload = async function() {
            const typedarray = new Uint8Array(this.result);
            try {
                const pdf = await pdfjsLib.getDocument({data: typedarray}).promise;
                let fullText = '';
                
                for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                    const page = await pdf.getPage(pageNum);
                    const textContent = await page.getTextContent();
                    const pageText = textContent.items.map(item => item.str).join(' ');
                    fullText += pageText + '\n';
                }
                resolve(fullText);
            } catch (err) {
                reject(err);
            }
        };
        fileReader.onerror = (err) => reject(err);
        fileReader.readAsArrayBuffer(file);
    });
}

// TXT Text Extraction
function extractTextFromTxt(file) {
    return new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.onload = function(e) {
            resolve(e.target.result);
        };
        fileReader.onerror = (err) => reject(err);
        fileReader.readAsText(file);
    });
}

// Helper: Normalize & clean text tokenization
function cleanTokens(text) {
    if (!text) return [];
    return text.toLowerCase()
        .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'+]/g, " ")
        .split(/\s+/)
        .filter(w => w.length > 1);
}

// Helper: Extract skills using predefined taxonomy + overlap
function extractSkillsFromText(text) {
    const found = new Set();
    const cleanText = text.toLowerCase();
    
    Object.values(skillTaxonomy).forEach(categorySkills => {
        categorySkills.forEach(skill => {
            // Check for full word matches or safe multi-word/special character checks
            if (skill.includes(' ') || skill.includes('+') || skill.includes('#') || skill.includes('.')) {
                if (cleanText.includes(skill)) {
                    found.add(skill);
                }
            } else {
                const regex = new RegExp(`\\b${skill}\\b`, 'g');
                if (regex.test(cleanText)) {
                    found.add(skill);
                }
            }
        });
    });
    
    return found;
}

// Helper: Calculate TF-IDF Cosine Similarity between two text documents (Machine Learning text similarity)
function calculateCosineSimilarity(text1, text2) {
    const tokens1 = cleanTokens(text1);
    const tokens2 = cleanTokens(text2);
    
    const stopWords = new Set(['the', 'and', 'a', 'of', 'to', 'in', 'is', 'for', 'with', 'on', 'at', 'by', 'an', 'this', 'that', 'it', 'as', 'are', 'be', 'or', 'from', 'your', 'our', 'we', 'you', 'will', 'requirement', 'job', 'description', 'role', 'responsibilities', 'experience', 'skills', 'candidate']);
    const filtered1 = tokens1.filter(t => !stopWords.has(t));
    const filtered2 = tokens2.filter(t => !stopWords.has(t));
    
    // Build Vocabulary
    const vocab = new Set([...filtered1, ...filtered2]);
    const vocabArray = Array.from(vocab);
    if (vocabArray.length === 0) return 0;
    
    // TF counts
    const TF1 = {}; filtered1.forEach(t => TF1[t] = (TF1[t] || 0) + 1);
    const TF2 = {}; filtered2.forEach(t => TF2[t] = (TF2[t] || 0) + 1);
    
    // Document Frequencies
    const DF = {};
    vocabArray.forEach(word => {
        let count = 0;
        if (TF1[word]) count++;
        if (TF2[word]) count++;
        DF[word] = count;
    });
    
    // IDF
    const N = 2;
    const IDF = {};
    vocabArray.forEach(word => {
        IDF[word] = Math.log(1 + (N / (DF[word] || 1)));
    });
    
    // TF-IDF vectors
    const vec1 = [];
    const vec2 = [];
    const maxTF1 = filtered1.length > 0 ? Math.max(...Object.values(TF1)) : 1;
    const maxTF2 = filtered2.length > 0 ? Math.max(...Object.values(TF2)) : 1;
    
    vocabArray.forEach(word => {
        const tfVal1 = TF1[word] ? (0.5 + 0.5 * (TF1[word] / maxTF1)) : 0;
        const tfVal2 = TF2[word] ? (0.5 + 0.5 * (TF2[word] / maxTF2)) : 0;
        vec1.push(tfVal1 * IDF[word]);
        vec2.push(tfVal2 * IDF[word]);
    });
    
    // Cosine Similarity
    let dotProduct = 0;
    let norm1 = 0;
    let norm2 = 0;
    for (let i = 0; i < vocabArray.length; i++) {
        dotProduct += vec1[i] * vec2[i];
        norm1 += vec1[i] * vec1[i];
        norm2 += vec2[i] * vec2[i];
    }
    if (norm1 === 0 || norm2 === 0) return 0;
    return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
}

// Local NLP matching logic
function runLocalNLPScreener(resumeText, jdText, filename) {
    const resumeSkills = extractSkillsFromText(resumeText);
    const jdSkills = extractSkillsFromText(jdText);
    
    // Skill overlap match
    const matched = [];
    const missing = [];
    
    jdSkills.forEach(skill => {
        if (resumeSkills.has(skill)) {
            matched.push(skill);
        } else {
            missing.push(skill);
        }
    });
    
    // Add extra candidate skills (found in resume but not in JD requirements, for context)
    const extraCandidateSkills = [];
    resumeSkills.forEach(skill => {
        if (!jdSkills.has(skill)) {
            extraCandidateSkills.push(skill);
        }
    });
    
    // Calculate Score Metrics using Machine Learning Cosine Similarity
    const cosineSim = calculateCosineSimilarity(resumeText, jdText);
    // Normalize cosine similarity (ranges typically 0.1 to 0.6) onto a human score curve 30% - 98%
    const skillsScore = Math.round(Math.min(Math.max(Math.sqrt(cosineSim) * 105, 30), 98));
        
    // Structure formatting & quality checks
    let qualityScore = 20;
    const cleanResume = resumeText.toLowerCase();
    if (cleanResume.includes('education') || cleanResume.includes('academic') || cleanResume.includes('university') || cleanResume.includes('college')) qualityScore += 20;
    if (cleanResume.includes('experience') || cleanResume.includes('employment') || cleanResume.includes('work history') || cleanResume.includes('professional history')) qualityScore += 20;
    if (cleanResume.includes('skills') || cleanResume.includes('technologies') || cleanResume.includes('core competencies')) qualityScore += 20;
    if (cleanResume.includes('project') || cleanResume.includes('portfolio') || cleanResume.includes('publications')) qualityScore += 20;
    if (/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/.test(cleanResume)) qualityScore += 10;
    if (/\+?[0-9]{7,15}/.test(cleanResume)) qualityScore += 10;
    
    // Deduct for very short or long resumes (ideal: 800 - 4500 characters)
    if (resumeText.length < 800) {
        qualityScore = Math.max(30, qualityScore - 25);
    } else if (resumeText.length > 5000) {
        qualityScore = Math.max(50, qualityScore - 10);
    }
    qualityScore = Math.min(qualityScore, 100);
    
    const resumeTokens = cleanTokens(resumeText);
    
    // Projects Match heuristic (30% weight)
    const projectKeywords = ['project', 'developed', 'built', 'git', 'github', 'personal', 'collaborative', 'academic', 'hackathon', 'portfolio', 'implemented', 'engineered', 'created', 'designed'];
    let projectWordCount = 0;
    resumeTokens.forEach(t => {
        if (projectKeywords.some(kw => t.includes(kw))) projectWordCount++;
    });
    const projectDensity = resumeTokens.length > 0 ? (projectWordCount / resumeTokens.length) : 0;
    const hasProjectsSection = cleanResume.includes('project') || cleanResume.includes('portfolio') || cleanResume.includes('publications');
    
    let projectsScore = Math.round(Math.min(Math.max(projectDensity * 450 + (hasProjectsSection ? 45 : 20), 40), 98));
    
    // Education & Certifications heuristic (15% weight)
    const eduKeywords = ['education', 'academic', 'degree', 'bachelor', 'master', 'btech', 'mca', 'mtech', 'bsc', 'university', 'college', 'gpa', 'cgpa', 'certification', 'certified', 'course', 'diploma', 'training', 'credentials'];
    let eduWordCount = 0;
    resumeTokens.forEach(t => {
        if (eduKeywords.some(kw => t.includes(kw))) eduWordCount++;
    });
    const eduDensity = resumeTokens.length > 0 ? (eduWordCount / resumeTokens.length) : 0;
    const hasEduSection = cleanResume.includes('education') || cleanResume.includes('academic') || cleanResume.includes('university') || cleanResume.includes('college');
    
    let educationScore = Math.round(Math.min(Math.max(eduDensity * 550 + (hasEduSection ? 50 : 25), 45), 98));
    
    // Overall Weighted Score (Skills Match: 45%, Projects Match: 30%, Education & Certs: 15%, Resume Quality: 10%)
    const score = Math.round((skillsScore * 0.45) + (projectsScore * 0.30) + (educationScore * 0.15) + (qualityScore * 0.10));
    
    // Distribute radar domains based on skill taxonomy
    const radarScore = {
        'Technical': 50,
        'Soft Skills': 50,
        'Leadership': 50,
        'Tools & Design': 50
    };
    
    // Calculate category presence
    const calculateCategoryScore = (categoryList) => {
        const found = categoryList.filter(s => resumeSkills.has(s));
        return Math.round(Math.min((found.length / Math.max(categoryList.length / 4, 3)) * 100, 100));
    };
    
    radarScore['Technical'] = Math.max(40, calculateCategoryScore(skillTaxonomy['Technical']));
    radarScore['Soft Skills'] = Math.max(50, calculateCategoryScore(skillTaxonomy['Soft Skills']));
    radarScore['Leadership'] = Math.max(40, Math.round((cleanResume.includes('lead') || cleanResume.includes('manage') || cleanResume.includes('direct') || cleanResume.includes('founder') || cleanResume.includes('mentored') ? 85 : 50)));
    
    const uiSkillsScore = calculateCategoryScore(skillTaxonomy['UI/UX Design']);
    const marketingSkillsScore = calculateCategoryScore(skillTaxonomy['Marketing & Growth']);
    radarScore['Tools & Design'] = Math.max(45, Math.round(uiSkillsScore * 0.5 + marketingSkillsScore * 0.5));
    
    // Extract Candidate Name heuristic
    let candidateName = filename.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ");
    candidateName = candidateName.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    
    // Try to find actual name in first few lines of text
    const lines = resumeText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length > 0) {
        const nameCandidate = lines[0];
        if (nameCandidate.length > 3 && nameCandidate.length < 30 && !nameCandidate.toLowerCase().includes('resume') && !nameCandidate.toLowerCase().includes('cv')) {
            candidateName = nameCandidate;
        }
    }
    
    // Template summary feedback
    const matchedStr = matched.slice(0, 3).join(', ');
    const missingStr = missing.slice(0, 3).join(', ');
    
    let summaryText = `Candidate profile screens with an overall compatibility match score of ${score}%. `;
    if (score >= 80) {
        summaryText += `${candidateName} demonstrates a strong fit with core requirements, specifically showcasing proficiency in keywords like [${matchedStr}]. `;
    } else if (score >= 60) {
        summaryText += `${candidateName} offers solid baseline competencies, though some key tool gaps were identified. Matched keywords include [${matchedStr}]. `;
    } else {
        summaryText += `The profile shows low overlap with requirements. Gaps are evident in critical skills, and project accomplishments may not align closely. `;
    }
    
    if (missing.length > 0) {
        summaryText += `Key missing competencies to verify include: ${missingStr || 'Specialist tools'}.`;
    }
    
    const strengths = [
        matched.length > 0 ? `Demonstrated knowledge in key requirements: ${matched.slice(0, 3).join(', ')}` : "Matches general vocabulary of the job requirements",
        projectsScore >= 80 ? "Substantial academic or personal project accomplishments listed" : "Contains projects documentation",
        educationScore >= 80 ? "Strong educational credentials and certifications background" : "Meets basic academic criteria"
    ];
    
    const weaknesses = [];
    if (missing.length > 0) {
        weaknesses.push(`Missing keyword matches in job requirements: ${missing.slice(0, 3).join(', ')}`);
    } else {
        weaknesses.push("Check depth of specific core tools listed");
    }
    if (qualityScore < 85) {
        weaknesses.push("Resume formatting and section density could be optimized for ATS screening");
    }
    if (projectsScore < 75) {
        weaknesses.push("Could showcase more detailed hands-on project accomplishments and technical implementation details");
    }
    
    const questions = [
        `Could you walk me through your hands-on experience with ${matched.slice(0, 2).join(' and ') || 'the key requirements of this role'}?`,
        missing.length > 0 ? `The job profile emphasizes ${missing[0]}. How would you rate your knowledge in this tool and have you worked in adjacent technologies?` : "What is a challenging project you've completed in a fast-paced setting?",
        "How do you keep your technical skills current with changing industry practices?"
    ];
    
    return {
        id: 'c_' + Math.random().toString(36).substr(2, 9),
        name: candidateName,
        filename: filename,
        score: score,
        skillsScore: skillsScore,
        projectsScore: projectsScore,
        educationScore: educationScore,
        qualityScore: qualityScore,
        skillsMatched: matched,
        skillsMissing: missing,
        skillsRadar: radarScore,
        summary: summaryText,
        strengths: strengths,
        improvements: weaknesses,
        questions: questions
    };
}

// Gemini API query handler removed

// Display Specific Candidate Details in Dashboard
function displayCandidateDetails(candidateId) {
    state.selectedCandidateId = candidateId;
    const cand = state.candidates.find(c => c.id === candidateId);
    if (!cand) return;
    
    // Switch visual views
    el.dashboardPlaceholder.classList.add('hidden');
    el.dashboardResults.classList.remove('hidden');
    
    // Identity fields
    el.candidateName.textContent = cand.name;
    el.candidateFilename.textContent = cand.filename;
    
    // Initials helper
    const nameParts = cand.name.split(' ');
    const initials = nameParts.map(p => p.charAt(0)).slice(0, 2).join('').toUpperCase();
    el.candidateInitials.textContent = initials || '??';
    
    // FIT Badge styling
    el.fitGradeBadge.className = 'badge';
    if (cand.score >= 80) {
        el.fitGradeBadge.textContent = 'High Fit';
        el.fitGradeBadge.classList.add('badge-high');
    } else if (cand.score >= 60) {
        el.fitGradeBadge.textContent = 'Medium Fit';
        el.fitGradeBadge.classList.add('badge-medium');
    } else {
        el.fitGradeBadge.textContent = 'Low Fit';
        el.fitGradeBadge.classList.add('badge-low');
    }
    
    // Method badge removed
    
    // Overall Radial animated progress
    el.scorePercentage.textContent = `${cand.score}%`;
    const offset = 377 - (377 * cand.score) / 100;
    el.scoreRadialFill.style.strokeDashoffset = offset;
    
    // Score components
    el.metricSkillsVal.textContent = `${cand.skillsScore}%`;
    el.barSkillsMatch.style.width = `${cand.skillsScore}%`;
    
    el.metricProjectsVal.textContent = `${cand.projectsScore}%`;
    el.barProjectsMatch.style.width = `${cand.projectsScore}%`;
    
    el.metricEduVal.textContent = `${cand.educationScore}%`;
    el.barEduMatch.style.width = `${cand.educationScore}%`;
    
    el.metricQualityVal.textContent = `${cand.qualityScore}%`;
    el.barQualityMatch.style.width = `${cand.qualityScore}%`;
    
    // Tab badge counters
    el.countMatched.textContent = cand.skillsMatched.length;
    el.countMissing.textContent = cand.skillsMissing.length;
    
    // Inject matching skill badges
    el.matchedSkillsContainer.innerHTML = '';
    if (cand.skillsMatched.length === 0) {
        el.matchedSkillsContainer.innerHTML = `<span class="text-muted" style="font-size:12px;">No matching skills detected.</span>`;
    } else {
        cand.skillsMatched.forEach(skill => {
            const badge = document.createElement('span');
            badge.className = 'skill-badge matched';
            badge.textContent = skill;
            el.matchedSkillsContainer.appendChild(badge);
        });
    }
    
    // Inject missing skill badges
    el.missingSkillsContainer.innerHTML = '';
    if (cand.skillsMissing.length === 0) {
        el.missingSkillsContainer.innerHTML = `<span class="text-muted" style="font-size:12px;">Zero missing skill gaps! Perfect keyword match.</span>`;
    } else {
        cand.skillsMissing.forEach(skill => {
            const badge = document.createElement('span');
            badge.className = 'skill-badge missing';
            badge.textContent = skill;
            el.missingSkillsContainer.appendChild(badge);
        });
    }
    
    // Report text areas
    el.reportSummary.textContent = cand.summary;
    
    // Strengths
    el.reportStrengths.innerHTML = '';
    cand.strengths.forEach(str => {
        const li = document.createElement('li');
        li.textContent = str;
        el.reportStrengths.appendChild(li);
    });
    
    // Weaknesses
    el.reportWeaknesses.innerHTML = '';
    cand.improvements.forEach(weak => {
        const li = document.createElement('li');
        li.textContent = weak;
        el.reportWeaknesses.appendChild(li);
    });
    
    // Interview Questions
    el.reportQuestions.innerHTML = '';
    cand.questions.forEach(q => {
        const li = document.createElement('li');
        li.textContent = q;
        el.reportQuestions.appendChild(li);
    });
    
    // Draw Radar Chart if active tab is the chart
    const activeTab = document.querySelector('.tab-btn.active').getAttribute('data-tab');
    if (activeTab === 'tab-chart') {
        renderRadarChart(cand.skillsRadar);
    }
}

// Chart.js Radar Render Utility
function renderRadarChart(skillsRadar) {
    if (state.skillsChart) {
        state.skillsChart.destroy();
    }
    
    const ctx = document.getElementById('skillsRadarChart').getContext('2d');
    const labels = Object.keys(skillsRadar);
    const dataValues = Object.values(skillsRadar);
    
    state.skillsChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Candidate Competency Fit',
                data: dataValues,
                fill: true,
                backgroundColor: 'rgba(99, 102, 241, 0.2)',
                borderColor: '#6366f1',
                pointBackgroundColor: '#06b6d4',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: '#6366f1',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                r: {
                    angleLines: {
                        color: 'rgba(255, 255, 255, 0.08)'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.08)'
                    },
                    pointLabels: {
                        color: '#94a3b8',
                        font: {
                            family: 'Outfit',
                            size: 11,
                            weight: 600
                        }
                    },
                    ticks: {
                        display: false,
                        stepSize: 20
                    },
                    min: 0,
                    max: 100
                }
            }
        }
    });
}

// Render rankings comparison table
function renderLeaderboard() {
    if (state.candidates.length === 0) {
        el.leaderboardTbody.innerHTML = `
            <tr class="empty-row">
                <td colspan="8">No candidates screened yet. Upload and screen to populate leaderboard.</td>
            </tr>
        `;
        el.btnExportCsv.disabled = true;
        return;
    }
    
    el.btnExportCsv.disabled = false;
    el.leaderboardTbody.innerHTML = '';
    
    // Sort candidates descending by score
    const sorted = [...state.candidates].sort((a, b) => b.score - a.score);
    
    sorted.forEach(cand => {
        const tr = document.createElement('tr');
        if (cand.id === state.selectedCandidateId) {
            tr.style.background = 'rgba(255, 255, 255, 0.02)';
        }
        
        let statusBadge = '';
        if (cand.score >= 80) {
            statusBadge = '<span class="badge badge-high">High Fit</span>';
        } else if (cand.score >= 60) {
            statusBadge = '<span class="badge badge-medium">Medium Fit</span>';
        } else {
            statusBadge = '<span class="badge badge-low">Low Fit</span>';
        }
        
        tr.innerHTML = `
            <td><strong>${cand.name}</strong></td>
            <td><span class="file-label" style="font-size:11px;">${cand.filename}</span></td>
            <td><strong style="color:#a855f7; font-size: 15px;">${cand.score}%</strong></td>
            <td>${cand.skillsScore}%</td>
            <td>${cand.projectsScore}%</td>
            <td>${cand.educationScore}%</td>
            <td>${cand.qualityScore}%</td>
            <td><span class="link-action view-cand-btn" data-id="${cand.id}">Inspect Dashboard</span></td>
        `;
        
        el.leaderboardTbody.appendChild(tr);
    });
    
    // Bind click listeners
    document.querySelectorAll('.view-cand-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = e.target.getAttribute('data-id');
            displayCandidateDetails(id);
            // Refresh table selection style
            renderLeaderboard();
        });
    });
}
 
// Export Leaderboard CSV Summary
function exportRankingsCsv() {
    if (state.candidates.length === 0) return;
    
    const headers = ['Candidate Name', 'Filename', 'Overall Match Score', 'Skills Score', 'Projects Score', 'Education Score', 'Resume Quality Score'];
    const rows = state.candidates.map(c => [
        `"${c.name}"`,
        `"${c.filename}"`,
        `"${c.score}%"`,
        `"${c.skillsScore}%"`,
        `"${c.projectsScore}%"`,
        `"${c.educationScore}%"`,
        `"${c.qualityScore}%"`
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
        + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
        
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `aura_ai_candidate_rankings_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification('Rankings CSV exported successfully!');
}
 
// Load Demo Profile Workflow
function loadDemoProfile() {
    const demoCandidate = {
        id: 'demo_nidhi',
        name: 'Nidhi Sharma',
        filename: 'nidhi_sharma_resume_software.pdf',
        score: 88,
        skillsScore: 90,
        projectsScore: 85,
        educationScore: 92,
        qualityScore: 90,
        skillsMatched: ['javascript', 'typescript', 'react', 'node.js', 'sql', 'git', 'rest api', 'agile', 'communication'],
        skillsMissing: ['next.js', 'docker', 'kubernetes'],
        skillsRadar: {
            'Technical': 88,
            'Soft Skills': 90,
            'Leadership': 70,
            'Tools & Design': 75
        },
        summary: 'Nidhi is a skilled Full-Stack Developer with over 4 years of practical experience building scalable web solutions. She displays exceptional proficiency in JavaScript/TypeScript ecosystems and database integrations.',
        strengths: [
            'Deep expertise in React.js component architectures and state management.',
            'Strong background implementing RESTful APIs with Node.js and PostgreSQL database querying.',
            'Effective collaborator, experienced with Agile workflows and sprint schedules.'
        ],
        improvements: [
            'No direct references to containerization tools (Docker/Kubernetes) listed on the profile.',
            'Familiarity with Next.js is not explicitly emphasized in projects.'
        ],
        questions: [
            'Can you describe your experience optimizing React component performance for complex data rendering?',
            'How have you managed database connection pooling and schema migrations in Node.js applications?',
            'What strategies do you use to coordinate work with design and product teams during sprints?'
        ],
        method: 'Aura NLP Demo'
    };
    
    // Add to state if not exists
    if (!state.candidates.some(c => c.id === demoCandidate.id)) {
        state.candidates.push(demoCandidate);
    }
    
    displayCandidateDetails(demoCandidate.id);
    renderLeaderboard();
    showNotification('Loaded demo profile: Nidhi Sharma');
}

// Spinner Controls
function showSpinner(title, subtitle) {
    el.spinnerTitle.textContent = title;
    el.spinnerSubtitle.textContent = subtitle;
    el.spinnerModal.classList.remove('hidden');
}

function updateSpinnerSub(text) {
    el.spinnerSubtitle.textContent = text;
}

function hideSpinner() {
    el.spinnerModal.classList.add('hidden');
}

// Local notifications banner
function showNotification(message, type = 'success') {
    const banner = document.createElement('div');
    banner.style.position = 'fixed';
    banner.style.bottom = '24px';
    banner.style.right = '24px';
    banner.style.zIndex = '1000';
    banner.style.padding = '12px 20px';
    banner.style.borderRadius = '8px';
    banner.style.fontFamily = 'Outfit, sans-serif';
    banner.style.fontSize = '14px';
    banner.style.fontWeight = '600';
    banner.style.display = 'flex';
    banner.style.alignItems = 'center';
    banner.style.gap = '10px';
    banner.style.boxShadow = '0 8px 32px 0 rgba(0, 0, 0, 0.4)';
    banner.style.animation = 'slide-up 0.3s cubic-bezier(0.16, 1, 0.3, 1)';
    
    let icon = '';
    if (type === 'success') {
        banner.style.background = 'rgba(16, 185, 129, 0.95)';
        banner.style.border = '1px solid rgba(16, 185, 129, 0.3)';
        banner.style.color = '#fff';
        icon = '✓';
    } else if (type === 'warning') {
        banner.style.background = 'rgba(245, 158, 11, 0.95)';
        banner.style.border = '1px solid rgba(245, 158, 11, 0.3)';
        banner.style.color = '#fff';
        icon = '⚠';
    } else {
        banner.style.background = 'rgba(239, 68, 68, 0.95)';
        banner.style.border = '1px solid rgba(239, 68, 68, 0.3)';
        banner.style.color = '#fff';
        icon = '🗙';
    }
    
    banner.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    document.body.appendChild(banner);
    
    setTimeout(() => {
        banner.style.animation = 'fade-out 0.4s ease forwards';
        setTimeout(() => {
            document.body.removeChild(banner);
        }, 400);
    }, 3000);
}

// CSS style override for fadeout
const styleSheet = document.createElement("style");
styleSheet.innerText = `
@keyframes fade-out {
    from { opacity: 1; transform: translateY(0); }
    to { opacity: 0; transform: translateY(10px); }
}
`;
document.head.appendChild(styleSheet);
