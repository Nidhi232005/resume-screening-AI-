# Aura AI - Resume Screener & Candidate Ranker

Aura AI is a modern, high-performance, and visually stunning client-side web application designed to automate resume screening and compare candidate profiles against specific Job Descriptions (JDs).

It executes entirely in the user's web browser, ensuring **maximum data privacy** and high execution speeds without requiring complex backend servers.

## Key Features

1. **PDF Text Extraction**: Parses uploaded PDF resumes directly in the browser using `PDF.js` (no document upload to external formatting servers).
2. **Dual Core Screening Engine**:
   - **Local NLP Matching**: A fast client-side keyword parser checking for skills taxonomy mapping, years of experience references, and ATS formatting standards.
   - **Google Gemini AI (Optional)**: Connect your Google Gemini API key to run a comprehensive, real-time semantic evaluation of your candidates.
3. **Interactive Visual Dashboard**:
   - Radial match scores with visual indicator glows.
   - ATS formatting metrics breakdown.
   - Skill overlap comparison displaying "Matched Skills" vs "Missing Skills".
   - Competency radar distribution charts (using `Chart.js`).
   - Detailed AI summaries, strengths, improvements, and interview questions.
4. **Rankings Leaderboard**:
   - Upload multiple profiles at once and automatically sort them by compatibility fit score.
   - Click to inspect specific candidates.
   - Export structured candidate rankings to CSV format.

## How to Run

1. Open the project folder `resume-screening-ai`.
2. Double-click the `index.html` file to open it in any web browser (Chrome, Edge, Firefox, Safari).
3. (Optional) Click the **Gemini API Config** button in the header, paste your Google Gemini API Key, and save it. It will be stored locally in your browser's `localStorage` for future runs.
4. To test immediately without uploading resumes: click **Load Demo Candidate Profile** on the landing dashboard to load sample evaluation data for candidate *Nidhi Sharma*.

## Project Structure

- `index.html` - The UI structure and container interfaces.
- `style.css` - Custom premium dark-themed styling, flexbox grids, and CSS animations.
- `app.js` - PDF reader, NLP calculations, Chart.js integrations, and Gemini API fetch connections.
- `README.md` - Documentation and instructions.

## Scoring Algorithm

The matching score is computed based on:
- **Skill Overlap (45%)**: Ratio of required skills matched against the Job Description.
- **Experience Alignment (35%)**: Heuristic mapping of years of experience requirements and seniority levels (e.g. Lead, Senior, Junior).
- **Resume Formatting (20%)**: Structural scan for contact details (email/phone) and standard resume modules (Education, Experience, Skills, Projects).
